import tkinter
from tkinter.constants import FALSE, TRUE
from typing import Text
from breezypythongui import EasyFrame
from tkinter import PhotoImage
from tkinter.font import Font
import tkinter.filedialog
import sys
from load import load
from savee import save
from loose import loose
from win import win


def num(self,att1,att2,deff1,deff2,count):# i want this in its own window
    EasyFrame.__init__(self,width=500,height=500,title="fight")
    self.setResizable(FALSE)
    self.addLabel(text=deff1,row=0,column=0)
    self.addLabel(text=deff2,row=0,column=0)
    while self.count >0:
        self.count=self.count -1
    while deff1>=0 or deff2>=0 :
        deff1=deff1-att2
        print(deff1)
        deff2=deff2-att1
        print(deff2)
                
    if deff1>=0:
        print("char1 is dead")
        self.loss=self.loss +1
        print ("loss",self.loss)
        loose(self)
        
    else:
        print("char2 is dead")
        print("win",self.win)
        self.win=self.win +1
        win(self)