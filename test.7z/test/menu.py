import tkinter
from tkinter.constants import FALSE, TRUE
from typing import Text
from breezypythongui import EasyFrame
from tkinter import PhotoImage
from tkinter.font import Font
import tkinter.filedialog
import sys
from load import load
from game import start
from savee import save
from loose import loose
from num import num
from win import win

class menu(EasyFrame):
    def __init__(self):#brings up another window in the window
        EasyFrame.__init__(self,width=500,height=500,title="number figher")
        self.setBackground("red")
        self.setResizable(FALSE)
        self.startbutton=self.addButton(text="start",row=1,column=1,command=self.start)
        self.load=self.addButton(text="load",row=2,column=1,command=self.load)
        self.save=self.addButton(text="save",row=3,column=1,command=self.save)
        self.exit=self.addButton(text="exit",row=4,column=1,command=self.quit)
        
   
    def start(self):
        start(self)
    def load(self):
        load(self)
    def save(self):
        save(self)
    def quit(self):
        sys.exit()

def main():
    menu().mainloop()
if __name__=="__main__":
    main()