import sys
def quit(self): 
        sys.exit()