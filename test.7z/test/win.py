import tkinter
from tkinter.constants import FALSE, TRUE
from typing import Text
from breezypythongui import EasyFrame
from tkinter import PhotoImage
from tkinter.font import Font
import tkinter.filedialog
import sys



def win(self,win):
    EasyFrame.__init__(self,width=500,height=500,title="try again")
    self.setResizable(TRUE)
    self.startbutton=self.addButton(text="start",row=0,column=1,command=self.start)
    self.exit=self.addButton(text="exit",row=0,column=2,command=self.quit)
    imageLable=self.addLabel(text="",row=0,column=0,sticky="NSEW")
    textLable=self.addLabel(text=("try again","win",self.win,"loss",self.loss),row=1,column=0,sticky="NSEW")
    self.image=PhotoImage(file="win.gif")#just adds more to the window, book does not tell how to make a new window
    imageLable["image"]=self.image
    font=Font(family="verdana",size=20)
    textLable["font"]=font
