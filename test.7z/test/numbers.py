import tkinter
from tkinter.constants import FALSE, TRUE
from typing import Text
from breezypythongui import EasyFrame
from tkinter import PhotoImage
from tkinter.font import Font
import tkinter.filedialog
import sys
import game


def num(self,deff1,deff2):
    EasyFrame.__init__(self,width=500,height=500,title="try again")
    self.addLabel(text=deff1,row=0,column=0)
    self.addLabel(text=deff2,row=0,column=0)