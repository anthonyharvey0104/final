 import tkinter
from tkinter.constants import FALSE, TRUE
from typing import Text
from breezypythongui import EasyFrame
from tkinter import PhotoImage
from tkinter.font import Font
import tkinter.filedialog
import sys 
  
  
  
def save(self):
    fileName=tkinter.filedialog.asksaveasfilename(parent=self)#i think this is the complete save for object programming the book dident go over this
    