import tkinter
from tkinter.constants import FALSE, TRUE
from typing import Text
from breezypythongui import EasyFrame
from tkinter import PhotoImage
from tkinter.font import Font
import tkinter.filedialog
import sys


def load(self):
        flist=[("Text files","*.txt")]
        fileName=tkinter.filedialog.askopenfilename(parent=self,filetypes=flist)
        if fileName!="":
            file=open(fileName,'r')
            text=file.read()
            file.close()
            self.outputArea.setText(text)
            self.setTitle(fileName)
            